document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll("nav ul li a").forEach(link => {
        if (link.href === window.location.href) link.style.fontWeight = "bold";
    });
});