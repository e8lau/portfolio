fetch('data/projects.json').then(response => response.json()).then(data => {
    let projectsList = document.getElementById('projects-list');
    data.projects.forEach(project => {
        let projectDiv = document.createElement('div');
        projectDiv.innerHTML = `<h3>${project.name}</h3><p>${project.description}</p>`;
        projectsList.appendChild(projectDiv);
    });
});